import React from "react";
import ReactDOM from "react-dom";
import GlowTracker from "./App";

ReactDOM.render(<GlowTracker />, document.getElementById("root"));